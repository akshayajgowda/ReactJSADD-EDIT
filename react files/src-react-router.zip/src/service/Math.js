var pi=3.14;
var MathLib = {};
MathLib.sum=function(a,b){return a+b;}
MathLib.mul=function(a,b){return a*b;}
export default MathLib;
