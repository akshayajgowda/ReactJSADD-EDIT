import React, { Component } from 'react';
import Menu from './Menu';
import Box from './Box';
class Aboutus extends Component {
   render() {
      return (
         <div>
         <Menu/>
            <h2>Aboutus</h2>
            <Box/>
         </div>
      );
   }
}
export default Aboutus;